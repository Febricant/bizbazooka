async(page)=>{
 const checks=[],errors=[],http=[];let offline=false;
 const check=(ok,label)=>{if(!ok)throw Error(label);checks.push(label);};
 const context=page.context();context.on('request',r=>{if(offline&&/^https?:/.test(r.url()))http.push(r.url());});context.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:4173/BizBazooka-demo.html');await page.evaluate(()=>document.fonts.ready);
 try{
 await context.setOffline(true);offline=true;await page.setViewportSize({width:390,height:844});
 for(const [name,title] of [['Product brief','BizBazooka — Founder ecosystem PRD'],['UX research','BizBazooka — UX research and founder ecosystem decisions'],['QA report','BizBazooka — QA report']]){
  const event=context.waitForEvent('page');await page.getByRole('link',{name,exact:true}).click();const doc=await event;await doc.waitForLoadState('domcontentloaded');
  check(doc.url().startsWith('blob:')&&((await doc.title()).includes(title)||name==='Product brief'&&(await doc.title()).includes('PRD')),name+' opens from an embedded offline document');
  check(await doc.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),name+' has no horizontal document overflow at 390px');
  if(name==='QA report'){
   check((await doc.locator('body').innerText()).includes('39 assertions passed')&&!(await doc.locator('body').innerText()).includes('Final verification in progress'),'Final QA results are embedded, not a placeholder');
   const nextEvent=context.waitForEvent('page');await doc.getByRole('link',{name:'UX research',exact:true}).click();const next=await nextEvent;await next.waitForLoadState('domcontentloaded');
   check(next.url().startsWith('blob:')&&(await next.title()).includes('UX research'),'Cross-document research link works offline');await next.close();
  }
  const closed=doc.waitForEvent('close');await doc.locator('.back').click();await closed;check(doc.isClosed(),name+' return control closes the document');
 }
 await page.locator('.partner-logos button').first().click();for(let i=0;i<3;i++){await page.getByRole('button',{name:'Inspect partner verification model',exact:true}).nth(i).click();check((await page.getByRole('dialog').innerText()).includes('SAMPLE PARTNERSHIP'), 'Partner verification model '+(i+1)+' opens a labeled sample record');await page.keyboard.press('Escape');}
 check(http.length===0,'Bundled document navigation and partner inspection make no HTTP requests');
 check(errors.length===0,'No uncaught browser errors in the final export');
 }finally{offline=false;await context.setOffline(false);}
 await page.goto('http://127.0.0.1:4173/');await page.setViewportSize({width:1440,height:1000});
 await page.getByRole('button',{name:'Reset demo',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Reset demo',exact:true}).click();
 await page.getByRole('button',{name:'Run the story',exact:true}).click();await page.getByRole('button',{name:'Recommend builders',exact:true}).click();check(await page.locator('.talent-card').count()===3,'Production Run the story opens venture recommendations with three eligible mobile builders after reset');
 check(await page.locator('.toast').evaluate(x=>getComputedStyle(x).pointerEvents)==='none','Production status notification does not intercept clicks');
 await page.getByRole('button',{name:'BizBazooka home',exact:true}).click();
 return {checks,errorCount:errors.length,http};
}
