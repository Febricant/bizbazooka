# BizBazooka visual specification · Founder ecosystem edition

Retain the user’s design.md and BizBazooka.html direction: cream canvas, graphite hero, portrait-card fan, DM Sans, rounded surfaces, restrained orange punctuation, line icons, and responsive cards.

## Current hierarchy

1. Build a venture. Launch a career. Accelerator/university positioning, venture team recommendation, and internship entry are visible in the hero.
2. Sample accelerator/university/community partnership cards lead to inspectable verification models.
3. Four core pillars: reviewed people/projects, equity, written agreement, and career/team opportunity.
4. Describe a venture and find explainable skill/capacity recommendations.
5. Discover sample people or founder projects before signup.
6. Founder recruiting flows progress through interview, candidate confirmation, offer, and separate candidate acceptance.
7. Founder internship posts include paid terms, mentor, and learning outcome.
8. Agreements show monthly, quarterly, or custom milestone vesting, with grant vs company percentages clearly separated.
9. VC discovery, guides, and pitch deck creation appear as planned ecosystem previews. No active VC persona.

## Responsive and evidence rules

Nine routes were checked at 360/390/640/768/820/1024/1440px. Narrow contract grids use shrinkable tracks and internal tab scrolling. The extended navigation collapses before it exceeds header width. Primary phone actions are comfortably sized; inputs use 16px text. Native dialogs retain keyboard focus and Escape handling. Toasts do not intercept underlying actions.

Affiliation and project badges are separate and clickable. Sample organizations and records remain labeled fictional. Newly created profiles stay self-reported. The final inspected gallery is output/playwright/index.html with images under output/playwright/ecosystem/.

All jobs, partners, badges, offers, contracts, and equity are prototype simulations. Real affiliation, hiring, legal execution, and share issuance are not asserted.
