import { seedOpportunities, type Opportunity, type Recruitment } from './ecosystem.ts';
import type { Deal, InvestorIntro, FounderProfile } from './venture';
export type Compensation = 'Paid' | 'Equity' | 'Portfolio';
export type RequestStatus = 'sent' | 'accepted' | 'declined' | 'withdrawn';
export interface Builder {
  id: string; name: string; role: string; discipline: string; location: string;
  skills: string[]; hours: number; terms: Compensation[]; bio: string;
  availableUntil: string; updated: string; consent: boolean;
  evidence: { title: string; detail: string; kind: string }[];
  initials: string; shade: string;
}
export interface Need {
  id: string; project: string; description: string; role: string; skills: string[];
  hours: number; weeks: number; start: string; terms: Compensation[];
  engagement?: 'Internship' | 'Long-term'; plannedMonths?:number; offeredEquity?:number; mentor?:string; learning?:string; pay?:string;
}
export interface Collaboration {
  id: string; builderId: string; need: Need; note: string; status: RequestStatus;
  created: string; founderCheckin?: boolean; builderCheckin?: boolean;
}
export interface Store {
  version: number; builders: Builder[]; needs: Need[]; requests: Collaboration[];
  deals: Deal[]; intros: InvestorIntro[]; founder?: FounderProfile; activeProfileId?: string;
  opportunities: Opportunity[]; recruitments: Recruitment[];
  events: { type: string; at: string }[];
}
export const STORE_KEY = 'bizbazooka-demo-v1';
export const today = () => new Date().toISOString().slice(0, 10);
export function addDays(date: string, days: number) {
  const d = new Date(date + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}
export function createNeed(): Need {
  return { id: crypto.randomUUID(), project: 'Tallyfield', description: 'A pre-order app for Calgary farmers’ markets. Help us build a simple mobile checkout so local vendors know what to bring.', role: 'Developer', skills: ['React Native', 'Stripe'], hours: 8, weeks: 6, start: today(), terms: ['Paid', 'Equity'] };
}
export function seedStore(): Store {
  const common = { location: 'Calgary, AB', availableUntil: addDays(today(), 84), updated: today(), consent: true };
  const builders: Builder[] = [
    { ...common, id: 'priya', name: 'Priya Shah', initials: 'PS', shade: 'sand', role: 'Full-stack developer', discipline: 'Developer', skills: ['React Native', 'Stripe', 'React', 'TypeScript', 'Node.js'], hours: 8, terms: ['Paid', 'Equity'], bio: 'I turn early ideas into things people can actually use. Particularly happy building thoughtful mobile experiences for local businesses.', evidence: [{ title: 'Market checkout', detail: 'Built a React Native + Stripe checkout in a weekend.', kind: 'Sample project evidence' }, { title: 'BuildYYC participant', detail: 'Illustrative event record. No organizer verification has been performed.', kind: 'Demo event record' }] },
    { ...common, id: 'daniel', name: 'Daniel Okafor', initials: 'DO', shade: 'clay', role: 'Mobile developer', discipline: 'Developer', skills: ['React Native', 'Stripe', 'TypeScript', 'Firebase'], hours: 10, terms: ['Paid', 'Equity', 'Portfolio'], bio: 'Mobile engineer, weekend cyclist, and believer in shipping small. Looking for a practical project with a clear finish line.', evidence: [{ title: 'Neighbourhood ordering app', detail: 'Two sample mobile projects with checkout flows.', kind: 'Sample project evidence' }] },
    { ...common, id: 'olivia', name: 'Olivia Chen', initials: 'OC', shade: 'paper', role: 'Product-minded developer', discipline: 'Developer', skills: ['React Native', 'Stripe', 'React', 'Python'], hours: 12, terms: ['Paid', 'Portfolio'], bio: 'From messy problem to useful prototype. I like teams that talk to customers and keep the first release small.', evidence: [{ title: 'Local goods storefront', detail: 'Sample payments integration for an independent maker.', kind: 'Sample project evidence' }] },
    { ...common, id: 'amara', name: 'Amara Khan', initials: 'AK', shade: 'stone', role: 'Frontend developer', discipline: 'Developer', skills: ['React Native', 'Stripe', 'React'], hours: 6, terms: ['Equity', 'Portfolio'], bio: 'Making the web a little more human, one small interaction at a time. Available for focused collaborations.', evidence: [{ title: 'Community marketplace', detail: 'Sample React storefront and checkout.', kind: 'Sample project evidence' }] },
    { ...common, id: 'marcus', name: 'Marcus Lee', initials: 'ML', shade: 'ink', role: 'Senior mobile engineer', discipline: 'Developer', skills: ['React Native', 'Stripe', 'React', 'TypeScript', 'Node.js'], hours: 0, terms: ['Paid', 'Equity'], bio: 'A decade of making products work. Fully committed right now; update your search when my capacity opens up.', evidence: [{ title: 'Five shipped products', detail: 'Illustrative portfolio record, not independently verified.', kind: 'Sample project evidence' }] },
    { ...common, id: 'sana', name: 'Sana Hassan', initials: 'SH', shade: 'sand', role: 'Product designer', discipline: 'Designer', skills: ['Figma', 'UX research', 'Prototyping', 'Design systems'], hours: 8, terms: ['Paid', 'Equity', 'Portfolio'], bio: 'Helping good ideas feel simple. I bring research, clear flows, and a slightly unreasonable love of typography.', evidence: [{ title: 'Community booking experience', detail: 'Sample end-to-end UX and interactive prototype.', kind: 'Sample project evidence' }] },
    { ...common, id: 'noah', name: 'Noah Williams', initials: 'NW', shade: 'paper', role: 'Product manager', discipline: 'Product manager', skills: ['Product strategy', 'Customer discovery', 'Roadmapping'], hours: 5, terms: ['Equity', 'Portfolio'], bio: 'Customer conversations first, roadmap second. Looking for a small team with a real problem to solve.', evidence: [{ title: 'A better volunteer signup', detail: 'Sample discovery and prioritization project.', kind: 'Sample project evidence' }] },
    { ...common, id: 'alex', name: 'Alex Rivera', initials: 'AR', shade: 'clay', role: 'Data & AI builder', discipline: 'Data specialist', skills: ['Python', 'SQL', 'Machine learning', 'Data visualization'], hours: 10, terms: ['Paid', 'Portfolio'], bio: 'Useful data tools over impressive demos. Here for the scrappy teams turning information into better decisions.', evidence: [{ title: 'Local demand forecasting', detail: 'Sample forecasting prototype using public data.', kind: 'Sample project evidence' }] },
  ];
  builders.push({...common,id:'jules',name:'Jules Park',initials:'JP',shade:'paper',role:'Early-career web builder',discipline:'Developer',skills:['React','TypeScript','Python','SQL'],hours:10,terms:['Paid','Equity','Portfolio'],bio:'Final-year student looking for a mentored internship and a first venture team.',evidence:[{title:'Campus services dashboard',detail:'Sample university capstone: accessible React dashboard.',kind:'Sample capstone evidence'}]});
  return { version: 3, opportunities:seedOpportunities(), recruitments:[], builders, needs: [], requests: [], deals: [], intros: [], events: [] };
}
export function readStore(): Store {
  try {
    const raw = JSON.parse(localStorage.getItem(STORE_KEY) || 'null');
    if ([1,2,3].includes(raw?.version) && Array.isArray(raw.builders) && Array.isArray(raw.requests) && Array.isArray(raw.needs) && Array.isArray(raw.events)) return { ...raw, version:3, builders:[...raw.builders,...seedStore().builders.filter(b=>b.id==='jules'&&!raw.builders.some((old:Builder)=>old.id===b.id))], activeProfileId:raw.activeProfileId?.startsWith('vc-')?'founder':raw.activeProfileId, opportunities:Array.isArray(raw.opportunities)?raw.opportunities:seedOpportunities(), recruitments:Array.isArray(raw.recruitments)?raw.recruitments:[], deals:Array.isArray(raw.deals)?raw.deals:[], intros:Array.isArray(raw.intros)?raw.intros:[] };
  } catch { /* A fresh demo is safe when stored data is unavailable. */ }
  return seedStore();
}
export function availableHours(builder: Builder, need: Need, requests: Collaboration[]) {
  const end = addDays(need.start, need.weeks * 7);
  const allocated = requests.filter(r => r.builderId === builder.id && r.status === 'accepted' && r.need.start < end && addDays(r.need.start, r.need.weeks * 7) > need.start).reduce((sum, r) => sum + r.need.hours, 0);
  return Math.max(0, builder.hours - allocated);
}
export function evaluate(builder: Builder, need: Need, requests: Collaboration[] = []) {
  const hours = availableHours(builder, need, requests);
  const matched = need.skills.filter(skill => builder.skills.some(s => s.toLowerCase() === skill.toLowerCase()));
  const missing = need.skills.filter(skill => !matched.includes(skill));
  const terms = need.terms.filter(t => builder.terms.includes(t));
  const blockers: string[] = [];
  if (!builder.consent) blockers.push('Not opted in to matching');
  if (builder.discipline !== need.role) blockers.push('Different role');
  if (missing.length) blockers.push('Missing ' + missing.join(', '));
  if (hours < need.hours) blockers.push(hours === 0 ? 'No available hours' : `Only ${hours} of ${need.hours} hrs/week available`);
  if (!terms.length) blockers.push('Compensation preferences differ');
  if (builder.availableUntil < addDays(need.start, need.weeks * 7)) blockers.push('Availability does not cover the full project');
  if (addDays(builder.updated, 14) < today()) blockers.push('Availability needs reconfirming');
  const score = Math.min(100, 70 + Math.min(15, builder.evidence.length * 7) + Math.min(10, Math.max(0, hours - need.hours) * 2) + Math.min(5, terms.length * 2));
  return { builder, hours, matched, missing, terms, blockers, eligible: blockers.length === 0, score };
}
export function getMatches(builders: Builder[], need: Need, requests: Collaboration[] = []) {
  return builders.map(b => evaluate(b, need, requests)).filter(m => m.eligible).sort((a, b) => b.score - a.score || a.builder.name.localeCompare(b.builder.name)).slice(0, 3);
}
export function validateNeed(need: Need): string | undefined {
  if (!need.project.trim() || !need.description.trim()) return 'Add a project name and a short description.';
  if (!need.skills.length) return 'Add at least one required skill.';
  if (!Number.isFinite(need.hours) || need.hours < 1 || need.hours > 40) return 'Choose between 1 and 40 hours per week.';
  if (!Number.isFinite(need.weeks) || need.weeks < 1 || need.weeks > 12) return 'Choose a duration between 1 and 12 weeks.';
  if (!need.terms.length) return 'Choose at least one compensation preference.';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(need.start) || need.start < today()) return 'Choose today or a future start date.';
}
export function transitionRequest(store: Store, id: string, next: RequestStatus, actor: 'founder' | string): Store {
  const request = store.requests.find(r => r.id === id);
  if (!request || request.status !== 'sent') throw new Error('This request has already been updated.');
  if (next === 'withdrawn' ? actor !== 'founder' : actor !== request.builderId || !['accepted', 'declined'].includes(next)) throw new Error('This action is not available for this demo role.');
  if (next === 'accepted') {
    const builder = store.builders.find(b => b.id === request.builderId);
    if (!builder || !evaluate(builder, request.need, store.requests).eligible) throw new Error('Capacity or preferences changed. Update the project before accepting.');
  }
  return { ...store, requests: store.requests.map(r => r.id === id ? { ...r, status: next } : r), events: [...store.events, { type: next, at: new Date().toISOString() }] };
}
