import { addDays, availableHours, createNeed, evaluate, getMatches, today, type Builder, type Compensation, type Need, type Store } from './model.ts';
export type CareerPath = 'Internship' | 'Long-term';
export interface Opportunity { id:string; project:string; title:string; description:string; skills:string[]; hours:number; weeks:number; mentor:string; learning:string; pay:string }
export interface CareerOffer { hours:number; weeks:number; plannedMonths:number; pay:string; equity:number; mentor:string; learning:string }
export interface Recruitment { id:string; builderId:string; path:CareerPath; need:Need; opportunityId?:string; stage:'applied'|'interview'|'confirmed'|'interviewed'|'offered'|'hired'|'declined'|'withdrawn'; interview?:{date:string; agenda:string}; offer?:CareerOffer; requestId?:string }
export const PARTNERS = [
 {id:'launch',name:'Prairie Launch',kind:'Accelerator',detail:'Cohort-reviewed founders, venture milestones, and project evidence.',badge:'Accelerator review',members:['priya','daniel']},
 {id:'university',name:'Northstar University',kind:'University',detail:'Student affiliation, capstone evidence, and mentored internship pathways.',badge:'University affiliation',members:['jules','sana']},
 {id:'community',name:'Campus Builders Collective',kind:'Builder community',detail:'Peer collaboration, portfolio evidence, and a first step into venture teams.',badge:'Community contribution',members:['alex','olivia']},
];
export const affiliations=(id:string)=>PARTNERS.filter(p=>p.members.includes(id));
export const seedOpportunities=():Opportunity[]=>[
 {id:'intern-tallyfield',project:'Tallyfield',title:'Frontend builder internship',description:'Build a small vendor dashboard with a founder mentor and weekly code reviews.',skills:['React','TypeScript'],hours:6,weeks:8,mentor:'Leah Morgan · weekly pairing and code review',learning:'Ship an accessible dashboard and document two customer learnings.',pay:'Paid internship · sample CAD 24/hour'},
 {id:'intern-clinic',project:'ClinicQueue',title:'Product design internship',description:'Turn clinic interviews into a testable appointment experience.',skills:['Figma','UX research'],hours:6,weeks:6,mentor:'Maya Tran · weekly research critique',learning:'Run three sample usability sessions and publish a case study.',pay:'Paid internship · sample CAD 24/hour'},
];
export function ventureNeed(idea:string,hours=6,terms:Compensation[]=['Paid','Equity']):{need:Need;reason:string} {
 if(!Number.isFinite(hours)||hours<1||hours>40||!terms.length)throw Error('Choose 1–40 hours and a compensation approach.');
 if(idea.trim().length<15)throw Error('Describe the problem and what you want to build in at least 15 characters.');
 let role='Developer',skills=['React','TypeScript'],reason='A web prototype suggests React and TypeScript.';
 if(/\b(ai|machine learning|forecast|analytics|data|prediction)\b/i.test(idea)){role='Data specialist';skills=['Python','SQL'];reason='Your data or AI idea suggests Python and SQL.';}
 else if(/design|research|figma|user experience|ux\b/i.test(idea)){role='Designer';skills=['Figma','UX research'];reason='Your research or design idea suggests Figma and UX research.';}
 else if(/mobile|checkout|payment|stripe/i.test(idea)){skills=['React Native','Stripe'];reason='Your mobile or payments idea suggests React Native and Stripe.';}
 else if(/customer discovery|product strategy|roadmap/i.test(idea)){role='Product manager';skills=['Product strategy','Customer discovery'];reason='Your discovery idea suggests product strategy and customer discovery.';}
 return {need:{...createNeed(),project:'My venture',description:idea.trim(),role,skills,hours,weeks:6,terms},reason};
}
export function recommendBuilders(s:Store,need:Need){return getMatches(s.builders,need,s.requests);}
const owns=(actor:string)=>{if(actor!=='founder')throw Error('Switch to the founder workspace for this action.');};
const find=(s:Store,id:string)=>{const r=s.recruitments.find(r=>r.id===id);if(!r)throw Error('Recruitment record not found.');return r;};
const pending=(s:Store,builderId:string,project:string)=>s.recruitments.some(r=>r.builderId===builderId&&r.need.project===project&&!['declined','withdrawn'].includes(r.stage));
export function postOpportunity(s:Store,value:Omit<Opportunity,'id'>,actor:string):Store{
 owns(actor);if(!value.project.trim()||!value.title.trim()||!value.description.trim()||!value.mentor.trim()||!value.learning.trim()||!value.pay.trim()||!value.skills.length)throw Error('Add the role, paid terms, mentor, learning goal, and skills.');
 if(!Number.isInteger(value.hours)||value.hours<1||value.hours>40||!Number.isInteger(value.weeks)||value.weeks<1||value.weeks>12)throw Error('Use 1–40 hours and a 1–12 week internship.');
 return {...s,opportunities:[...s.opportunities,{...value,id:crypto.randomUUID()}]};
}
export function applyToOpportunity(s:Store,id:string,actor:string,consent:boolean):Store{
 const b=s.builders.find(b=>b.id===actor),o=s.opportunities.find(o=>o.id===id);if(!b||!o)throw Error('Choose a builder workspace before applying.');if(!consent)throw Error('Choose to share your demo profile with this founder.');if(pending(s,b.id,o.project))throw Error('An active application already exists for this venture.');
 const need:Need={...createNeed(),project:o.project,description:o.description,skills:o.skills,role:b.discipline,hours:o.hours,weeks:o.weeks,terms:['Paid'],engagement:'Internship',mentor:o.mentor,learning:o.learning,pay:o.pay};
 return {...s,recruitments:[...s.recruitments,{id:crypto.randomUUID(),builderId:b.id,path:'Internship',need,opportunityId:o.id,stage:'applied'}]};
}
export function inviteInterview(s:Store,builderId:string,need:Need,path:CareerPath,date:string,agenda:string,actor:string,existingId?:string):Store{
 owns(actor);const b=s.builders.find(b=>b.id===builderId);if(!b||!b.consent)throw Error('Choose a builder who has opted into matching.');if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||Number.isNaN(Date.parse(date))||date<today())throw Error('Choose today or a future interview date.');if(!agenda.trim())throw Error('Add an interview agenda.');
 if(existingId){const r=find(s,existingId);if(r.stage!=='applied')throw Error('This application already progressed.');return {...s,recruitments:s.recruitments.map(x=>x.id===r.id?{...x,stage:'interview',interview:{date,agenda:agenda.trim()}}:x)};}
 if(pending(s,builderId,need.project))throw Error('An active recruiting conversation already exists for this venture.');
 return {...s,recruitments:[...s.recruitments,{id:crypto.randomUUID(),builderId,path,need:{...need,engagement:path},stage:'interview',interview:{date,agenda:agenda.trim()}}]};
}
export function confirmInterview(s:Store,id:string,actor:string):Store{const r=find(s,id);if(actor!==r.builderId||r.stage!=='interview')throw Error('Only the invited candidate can confirm this interview.');return {...s,recruitments:s.recruitments.map(x=>x.id===id?{...x,stage:'confirmed'}:x)};}
export function completeInterview(s:Store,id:string,actor:string):Store{owns(actor);const r=find(s,id);if(r.stage!=='confirmed')throw Error('The candidate must confirm the interview first.');return {...s,recruitments:s.recruitments.map(x=>x.id===id?{...x,stage:'interviewed'}:x)};}
export function makeCareerOffer(s:Store,id:string,offer:CareerOffer,actor:string):Store{
 owns(actor);const r=find(s,id);if(r.stage!=='interviewed')throw Error('Complete the confirmed interview before making an offer.');
 if(!Number.isInteger(offer.hours)||offer.hours<1||offer.hours>40||!Number.isInteger(offer.weeks)||offer.weeks<1||offer.weeks>12||!Number.isInteger(offer.plannedMonths)||offer.plannedMonths<1||offer.plannedMonths>60)throw Error('Check hours, initial scope (1–12 weeks), and long-term plan (1–60 months).');
 if(!Number.isFinite(offer.equity)||offer.equity<0||offer.equity>100||!offer.pay.trim())throw Error('Add paid terms and an equity option between 0% and 100%.');
 if(offer.equity>0&&!s.builders.find(b=>b.id===r.builderId)?.terms.includes('Equity'))throw Error('This candidate is not open to equity.');
 if(r.path==='Internship'&&(!offer.mentor.trim()||!offer.learning.trim()))throw Error('An internship needs a mentor and a learning outcome.');
 return {...s,recruitments:s.recruitments.map(x=>x.id===id?{...x,offer:{...offer},stage:'offered'}:x)};
}
export function acceptCareerOffer(s:Store,id:string,actor:string,consent:boolean):Store{
 const r=find(s,id),b=s.builders.find(b=>b.id===actor);if(!b||r.builderId!==actor||r.stage!=='offered'||!r.offer)throw Error('Only this candidate can accept their pending offer.');if(!consent)throw Error('Acknowledge the nonbinding offer before accepting.');
 const o=r.offer;const need:Need={...r.need,hours:o.hours,weeks:o.weeks,start:today(),terms:o.equity>0?['Paid','Equity']:['Paid'],engagement:r.path,plannedMonths:o.plannedMonths,offeredEquity:o.equity,mentor:o.mentor,learning:o.learning,pay:o.pay};
 if(!evaluate(b,need,s.requests).eligible)throw Error('The candidate’s skills, current capacity, dates, or preferences no longer cover this initial scope.');
 const requestId=crypto.randomUUID();return {...s,needs:[...s.needs,need],requests:[...s.requests,{id:requestId,builderId:b.id,need,note:'Mutually accepted demo recruiting offer after interview.',status:'accepted',created:new Date().toISOString()}],recruitments:s.recruitments.map(x=>x.id===id?{...x,need,stage:'hired',requestId}:x)};
}
export function closeRecruitment(s:Store,id:string,actor:string):Store{const r=find(s,id);if(!['applied','interview','confirmed','interviewed','offered'].includes(r.stage)||!['founder',r.builderId].includes(actor))throw Error('This recruitment can no longer be closed.');return {...s,recruitments:s.recruitments.map(x=>x.id===id?{...x,stage:actor==='founder'?'withdrawn':'declined'}:x)};}
export const careerSummary=(r:Recruitment,b:Builder)=>`NONBINDING CAREER OFFER · DEMO ONLY\n${r.need.project} · ${r.path}\nCandidate: ${b.name}\nInitial scope: ${r.offer?.hours} hrs/week for ${r.offer?.weeks} weeks\nLong-term plan: ${r.offer?.plannedMonths} months (subject to future availability)\nPaid terms: ${r.offer?.pay}\nEquity option: ${r.offer?.equity}% proposed, no shares or rights created\nMentor: ${r.offer?.mentor||'To agree'}\nLearning goals: ${r.offer?.learning||'To agree'}\nStatus: ${r.stage}\nNo employment, placement, message, contract, payment, or equity issuance is created.\n`;
