import type { Builder, Store, Need } from './model';
export interface FounderProfile { name: string; project: string; consent: boolean }
export interface VestingMilestone { month:number; percent:number; label:string }
export interface EquityTerms { vestingCadence?:'monthly'|'quarterly'|'milestone'; milestones?:VestingMilestone[]; equity: number; vestingMonths: number; cliffMonths: number; deliverable: string; ip: string }
export interface DemoSignature { name: string; at: string; revision: number }
export interface Deal { id: string; requestId: string; builderId: string; need: Need; founderName: string; terms: EquityTerms; revision: number; stage: 'draft' | 'review' | 'accepted'; founderSignature?: DemoSignature; builderSignature?: DemoSignature; investorVisible: boolean; created: string }
export interface InvestorIntro { id: string; dealId: string; vcId: string; direction: 'founder_to_vc' | 'vc_to_founder'; note: string; status: 'requested' | 'accepted' | 'declined' | 'withdrawn'; created: string }
export const VCS = [
  { id: 'vc-nora', name: 'Nora Bennett', firm: 'Prairie Demo Ventures', focus: 'Agtech & community commerce', stage: 'Pre-seed / seed', initials: 'NB', portrait: 'maya' },
  { id: 'vc-micah', name: 'Micah Reed', firm: 'Frontier Demo Partners', focus: 'Fintech & developer tools', stage: 'Pre-seed', initials: 'MR', portrait: 'owen' },
  { id: 'vc-sam', name: 'Sam Patel', firm: 'Riverbend Demo Capital', focus: 'Health & applied AI', stage: 'Seed', initials: 'SP', portrait: 'leah' },
];
export const isInvestor = (actor: string) => actor.startsWith('vc-');
export const portraitFor = (id: string) => { const path=['priya','daniel','olivia','leah','owen','maya'].includes(id)?`/images/${id}-reference.svg`:'/images/priya-reference.svg'; return (globalThis as typeof globalThis & {__BIZBAZOOKA_ASSETS__?:Record<string,string>}).__BIZBAZOOKA_ASSETS__?.[path]||path; };
export const industries: Record<string, string> = { priya:'Agtech', daniel:'Health', olivia:'Fintech', amara:'Fintech', marcus:'Fintech', sana:'Creative', noah:'Community', alex:'Energy', jules:'Campus' };
export function hasDemoProof(b: Builder) { return ['priya','daniel','olivia','sana','alex','jules'].includes(b.id) && b.evidence.length > 0; }
export const defaultTerms = (): EquityTerms => ({ equity:0.5, vestingCadence:'monthly', vestingMonths:24, cliffMonths:6, deliverable:'Deliver a working mobile checkout prototype, payment integration, and a documented handover.', ip:'Ownership, background IP, licences, and confidentiality require a separately reviewed agreement.' });
export function validateEquityTerms(t: EquityTerms) {
  if (!Number.isFinite(t.equity) || t.equity <= 0 || t.equity > 100) return 'Equity must be greater than 0% and no more than 100%.';
  if (!Number.isInteger(t.vestingMonths) || t.vestingMonths < 1 || t.vestingMonths > 120) return 'Vesting must be between 1 and 120 whole months.';
  if (!Number.isInteger(t.cliffMonths) || t.cliffMonths < 0 || t.cliffMonths > t.vestingMonths) return 'The cliff must be between zero and the vesting period.';
  if (t.vestingCadence && !['monthly','quarterly','milestone'].includes(t.vestingCadence)) return 'Choose a supported vesting schedule.';
  if (t.vestingCadence==='milestone') {
    if(!t.milestones?.length)return 'Add at least one milestone.';
    if(t.milestones.some((m,i)=>!m.label.trim()||!Number.isInteger(m.month)||m.month<Math.max(1,t.cliffMonths)||m.month>t.vestingMonths||(i>0&&m.month<=t.milestones![i-1].month)||!Number.isFinite(m.percent)||m.percent<=0))return 'Use named milestones in increasing months, after the cliff and within the vesting period.';
    if(Math.abs(t.milestones.reduce((sum,m)=>sum+m.percent,0)-100)>0.001)return 'Milestones must allocate exactly 100% of the proposed grant.';
    if(t.milestones.at(-1)!.month!==t.vestingMonths)return 'The final milestone must match the vesting period.';
  }
  if (!t.deliverable.trim() || t.deliverable.length > 1000) return 'Describe a deliverable in 1–1,000 characters.';
  if (!t.ip.trim()) return 'Include an IP and confidentiality discussion note.';
}
const event = (type: string) => ({ type, at:new Date().toISOString() });
export function openDeal(s: Store, requestId: string, actor: string): { store: Store; id: string } {
  if (actor !== 'founder') throw new Error('Switch to the founder demo role to propose a partnership.');
  const r=s.requests.find(r=>r.id===requestId && r.status==='accepted');
  if (!r) throw new Error('Start with a mutually accepted introduction.');
  if (!r.need.terms.includes('Equity') || !s.builders.find(b=>b.id===r.builderId)?.terms.includes('Equity')) throw new Error('Both participants must be open to equity.');
  const old=s.deals.find(d=>d.requestId===requestId); if(old)return {store:s,id:old.id};
  const deal:Deal={id:crypto.randomUUID(),requestId,builderId:r.builderId,need:r.need,founderName:s.founder?.name||'Leah Morgan',terms:{...defaultTerms(),equity:r.need.offeredEquity||0.5,deliverable:`Contribute to ${r.need.project}: ${r.need.description} Agreed initial scope: ${r.need.hours} hours/week for ${r.need.weeks} weeks.`},revision:1,stage:'draft',investorVisible:false,created:new Date().toISOString()};
  return {store:{...s,deals:[...s.deals,deal],events:[...s.events,event('equity_draft_started')]},id:deal.id};
}
export function saveDealTerms(s:Store,id:string,terms:EquityTerms,actor:string):Store {
  const deal=s.deals.find(d=>d.id===id); if(!deal||actor!=='founder')throw new Error('Only the founder demo role can update these terms.');
  if(deal.stage==='accepted')throw new Error('The accepted demo agreement is locked.');
  const error=validateEquityTerms(terms);if(error)throw new Error(error);
  return {...s,deals:s.deals.map(d=>d.id!==id?d:{...d,terms:{...terms,milestones:terms.milestones?.map(m=>({...m})),deliverable:terms.deliverable.trim(),ip:terms.ip.trim()},revision:d.revision+1,stage:'review',founderSignature:undefined,builderSignature:undefined,investorVisible:false}),events:[...s.events,event('agreement_review_started')]};
}
const normalized=(s:string)=>s.trim().replace(/\s+/g,' ').toLowerCase();
export function signDemoDeal(s:Store,id:string,actor:string,name:string,acknowledged:boolean):Store {
  const d=s.deals.find(d=>d.id===id);if(!d||d.stage!=='review')throw new Error('Review current terms before simulating a signature.');
  if(actor!=='founder'&&actor!==d.builderId)throw new Error('Only this founder or builder can simulate their own signature.');
  if(!acknowledged)throw new Error('Confirm that you understand this is a nonbinding demo.');
  const expected=actor==='founder'?d.founderName:s.builders.find(b=>b.id===d.builderId)?.name;
  if(!expected||normalized(name)!==normalized(expected))throw new Error(`Enter ${expected||'the participant’s name'} exactly.`);
  const key=actor==='founder'?'founderSignature':'builderSignature';if(d[key])throw new Error('This participant has already signed this revision.');
  const updated={...d,[key]:{name:expected,at:new Date().toISOString(),revision:d.revision}};
  if(updated.founderSignature?.revision===d.revision&&updated.builderSignature?.revision===d.revision)updated.stage='accepted';
  return {...s,deals:s.deals.map(x=>x.id===id?updated:x),events:[...s.events,event(updated.stage==='accepted'?'demo_agreement_completed':'demo_signature_added')]};
}
export function setInvestorVisibility(s:Store,id:string,visible:boolean,actor:string):Store {
  const d=s.deals.find(d=>d.id===id);if(actor!=='founder'||!d||d.stage!=='accepted')throw new Error('The founder can enable visibility after both demo signatures.');
  return {...s,deals:s.deals.map(d=>d.id===id?{...d,investorVisible:visible}:d),events:[...s.events,event(visible?'investor_visibility_enabled':'investor_visibility_revoked')]};
}
export function requestInvestorIntro(s:Store,dealId:string,vcId:string,direction:InvestorIntro['direction'],note:string,consent:boolean,actor:string):Store {
  const d=s.deals.find(d=>d.id===dealId);if(!d||d.stage!=='accepted'||!d.investorVisible)throw new Error('Complete the demo partnership and opt in to investor visibility first.');
  if(!VCS.some(v=>v.id===vcId))throw new Error('Select an investor from this demo.');
  if(direction==='founder_to_vc'?actor!=='founder':actor!==vcId)throw new Error('Switch to the correct demo role to request this introduction.');
  if(!consent)throw new Error('Choose to share this demo profile before requesting an introduction.');
  if(!note.trim()||note.length>800)throw new Error('Add a short introduction, up to 800 characters.');
  if(s.intros.some(i=>i.dealId===dealId&&i.vcId===vcId&&['requested','accepted'].includes(i.status)))throw new Error('An active introduction already exists for this partnership and investor.');
  const intro:InvestorIntro={id:crypto.randomUUID(),dealId,vcId,direction,note:note.trim(),status:'requested',created:new Date().toISOString()};
  return {...s,intros:[...s.intros,intro],events:[...s.events,event('investor_intro_requested')]};
}
export function respondInvestorIntro(s:Store,id:string,status:'accepted'|'declined'|'withdrawn',actor:string):Store {
  const i=s.intros.find(i=>i.id===id);if(!i||i.status!=='requested')throw new Error('This introduction has already been updated.');
  const receiver=i.direction==='founder_to_vc'?i.vcId:'founder',sender=i.direction==='founder_to_vc'?'founder':i.vcId;
  if(actor!==(status==='withdrawn'?sender:receiver))throw new Error('Only the recipient can respond, or the sender can withdraw.');
  return {...s,intros:s.intros.map(i=>i.id===id?{...i,status}:i),events:[...s.events,event('investor_intro_'+status)]};
}
export function vestingSchedule(t:EquityTerms):{month:number;percent:number;equity:number;label:string}[]{
 if(validateEquityTerms(t))return [];
 if(t.vestingCadence==='milestone')return t.milestones!.map(m=>({...m,equity:Number((t.equity*m.percent/100).toFixed(6))}));
 const step=t.vestingCadence==='quarterly'?3:1;const months:number[]=[];
 for(let m=t.cliffMonths>0?t.cliffMonths:step;m<t.vestingMonths;m+=step)months.push(m);
 months.push(t.vestingMonths);let prior=0;
 return months.map(month=>{const cumulative=Number((month/t.vestingMonths*100).toFixed(4));const percent=Number((cumulative-prior).toFixed(4));prior=cumulative;return {month,percent,equity:Number((t.equity*percent/100).toFixed(6)),label:month===t.cliffMonths?'Cliff / accumulated period':'Scheduled vesting'};});
}
export function agreementText(d:Deal,b:Builder) {
  return `BIZBAZOOKA — NONBINDING DEMO AGREEMENT\nSAMPLE ONLY. NOT A LEGAL DOCUMENT OR OFFER OF SECURITIES.\n\nProject: ${d.need.project}\nRevision: ${d.revision}\nFounder: ${d.founderName}\nBuilder: ${b.name}\n\n1. Contribution\n${d.terms.deliverable}\n${d.need.hours} hours/week for ${d.need.weeks} weeks, starting ${d.need.start}.\n\n2. Equity intent\n${d.terms.equity}% proposed equity. Illustrative vesting: ${d.terms.vestingMonths} months; cliff: ${d.terms.cliffMonths} months.\nCadence: ${d.terms.vestingCadence||'monthly'}. Each allocation below is a percentage of the proposed grant, not of company ownership.\n${vestingSchedule(d.terms).map(row=>`Month ${row.month}: ${row.percent}% of grant (${row.equity}% company equity intent) · ${row.label}`).join('\n')}\nEngagement: ${d.need.engagement||'Project collaboration'}; long-term plan: ${d.need.plannedMonths||'not set'} months. Paid terms: ${d.need.pay||'To agree'}.\nNo shares, options, ownership, investment rights, or payment are created by this prototype.\n\n3. IP and confidentiality\n${d.terms.ip}\n\n4. Changes and exit\nAny change to scope, equity, IP, confidentiality, termination, or vesting requires a separately reviewed agreement.\n\n5. Independent review\nThe parties must obtain independent professional advice and approved company documentation before a real arrangement. No lawyer review is claimed for this sample.\n\n6. Demo acceptance\nFounder: ${d.founderSignature?.name||'Pending'}\nBuilder: ${d.builderSignature?.name||'Pending'}\nStatus: ${d.stage==='accepted'?'ACCEPTED IN DEMO ONLY':'DRAFT / DEMO REVIEW'}\n\nThis download is a prototype discussion record, not an executed agreement.\n`;
}
