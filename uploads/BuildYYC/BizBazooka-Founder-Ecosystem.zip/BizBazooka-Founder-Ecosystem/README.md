# BizBazooka · Founder and career ecosystem

Build a venture. Launch a career. A responsive BuildYYC prototype for accelerator/university partnership discovery, reviewed builder/project evidence, venture-based recommendations, interviews, mentored internships, long-term recruiting, and versioned equity vesting agreements.

## Run

Node 22.20+ and npm. No API keys, accounts, database, or environment variables.

```sh
npm ci
npm run dev
npm test
npm run export
npm run preview -- --port 4173
```

Development: http://127.0.0.1:5173 (or the next available port). Production preview: http://127.0.0.1:4173. `dist/` is the static website. `BizBazooka-demo.html` embeds the app, fonts, portraits, PRD, research, and QA. The offline interaction checks load it locally, then disable browser network access. Direct file-protocol navigation is not certified by automation.

## Main demo

1. Reset demo in the footer. Enter a web dashboard venture in the homepage idea form.
2. Recommend builders, inspect Jules Park’s university affiliation and capstone evidence, and invite a long-term interview.
3. View candidate interview, confirm, return to founder interview notes, and mark the interview complete.
4. Prepare a paid offer with a longer-term plan and optional equity. The initial 1–12 week work scope is separate from the 1–60 month longer-term plan.
5. View candidate offer, acknowledge its nonbinding status, and accept. The initial scope reserves current capacity once.
6. Return to founder contract preparation and review equity/vesting. Choose monthly, quarterly, or custom milestone periods. Review/download and simulate founder and builder signatures.
7. Open Internship opportunities. Post a role with paid terms, mentor, learning outcome, skills, hours, and duration. Preview as Jules, apply with consent, and follow the interview → offer → candidate acceptance flow.
8. Open Ecosystem for sample partnership verification models and planned VC-list, how-to guide, and pitch-deck workflows.

Run the story opens the founder/team workspace. Use the header role switch to inspect founder and builder perspectives. No VC persona is available. Reset before replaying a complete story because accepted work reserves capacity.

## Implemented

- USP-led homepage, sample accelerator/university/community partnership cards, and role-specific profile creation.
- Separate project-review and affiliation badges linked to a provenance dossier. New profiles stay self-reported.
- Venture idea → explainable skill inference → existing consent, skill, capacity, date, freshness, and compensation matching rules. These are keyword rules, not AI predictions.
- Founder interview invitation, candidate confirmation, founder completion, offer preparation, candidate acknowledgment and acceptance, and pending-record closure.
- Founder-posted mentored internships, candidate profile-sharing consent, application, interview, paid offer, and first-career-step acceptance.
- Long-term recruiting with paid terms and optional equity intent, separate initial/longer-term periods, revalidated acceptance, and capacity reservation.
- Monthly and quarterly vesting with cliff catch-up, or custom increasing milestone periods totaling 100% of a grant. Agreement previews and text exports distinguish grant allocation from company equity.
- Existing mutual collaboration introductions, decline/withdrawal, profile/capacity editing, check-ins, organizer view, navigation, local persistence, and scoped reset.
- Ecosystem roadmap previews for VC discovery, how-to guides, and easy pitch deck creation. These are planned features, not active services.

## Data and boundaries

Version 3 migrates version 1/2 browser data under `bizbazooka-demo-v1`; saved work is preserved. An old VC role becomes founder. The old `?view=investors` route opens Ecosystem. Legacy investor domain records remain migration compatibility data and have no active UI.

Every seed person, institutional partnership, badge, project, and evidence record is fictional. No real affiliation, endorsement, hiring, internship placement, employment, calendar event, external message, executed contract, equity option, share issuance, payment, investment, or professional review is created. Role switching is not authentication. Longer-term offers do not guarantee future capacity. Use sample details.

A real pilot needs authenticated shared data, server authorization, real reviewer provenance, consent and revocation, notifications/calendar delivery, reviewed employment and equity documents, and appropriate company approvals.

## Files

- `public/docs/PRD.html`: current founder/career PRD and acceptance rules.
- `public/docs/UX-RESEARCH.html`: prior primary-source UX research with updated scope rationale. No measured conversion uplift.
- `public/docs/QA.html`, `VERIFICATION.md`: 38 unit tests, 66 browser behavior assertions, 63 responsive checks, 41 offline assertions, and verification limits.
- `src/TalentUI.tsx`, `src/ecosystem.ts`, `src/ecosystem.css`: partner, recommendation, internship, and recruiting flows.
- `src/VestingUI.tsx`, `src/venture.ts`, `src/VentureUI.tsx`: cadence/milestone calculation and versioned agreement UI.
- `src/App.tsx`, `src/model.ts`: app state, navigation, profiles, collaboration, and migration.
- `tests/`: 38 domain tests, including retained legacy-record regression tests.
- `output/playwright/ecosystem/`: current executable browser checks, screenshots, and evidence. Earlier VC screenshots are historical, not the current design.
- `output/playwright/index.html`: latest mockup gallery.

The supplied design.md and BizBazooka.html inform the retained cream/dark visual language and portrait composition. DM Sans is bundled under SIL OFL (`public/images/OFL.txt`); portraits derive from the user reference. Lucide is ISC. A local illustrative Unsplash workspace image remains in source assets.
