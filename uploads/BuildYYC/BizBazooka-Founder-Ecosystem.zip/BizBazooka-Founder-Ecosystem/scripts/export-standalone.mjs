import { readFile, writeFile, readdir } from 'node:fs/promises';
import { resolve } from 'node:path';
const root = process.cwd();
const data = async (path, type) => `data:${type};base64,${(await readFile(resolve(root, path))).toString('base64')}`;
let html = await readFile('dist/index.html', 'utf8');
const jsPath = html.match(/<script[^>]+src="([^"]+)"[^>]*><\/script>/)?.[1];
const cssPath = html.match(/<link[^>]+href="([^"]+\.css)"[^>]*>/)?.[1];
if (!jsPath || !cssPath) throw new Error('Build output is missing JavaScript or CSS. Run npm run build first.');
let js = await readFile(resolve('dist', jsPath.replace(/^\//, '')), 'utf8');
let css = await readFile(resolve('dist', cssPath.replace(/^\//, '')), 'utf8');
js = js.replaceAll('/images/builders.jpg', await data('public/images/builders.jpg', 'image/jpeg'));
for (const filename of ['dm-sans-regular.ttf', 'dm-sans-medium.ttf']) css = css.replaceAll(`/images/${filename}`, await data(`public/images/${filename}`, 'font/ttf'));
const favicon = await data('public/favicon.svg', 'image/svg+xml');
html = html.replace(/href="\/favicon.svg"/, `href="${favicon}"`);
const assets = {};
for (const name of await readdir('public/images')) if(name.endsWith('-reference.svg')) assets[`/images/${name}`] = await data(`public/images/${name}`, 'image/svg+xml');
html = html.replace('<head>', `<head><script>window.__BIZBAZOOKA_ASSETS__=${JSON.stringify(assets)};</script>`);
html = html.replace(/<link[^>]+href="[^"]+\.css"[^>]*>/, () => `<style>${css}</style>`);
html = html.replace(/<script[^>]+src="[^"]+"[^>]*><\/script>/, () => `<script type="module">${js.replaceAll('</script', '<\\/script')}</script>`);
const docs = {};
for(const file of await readdir('public/docs')) if(file.endsWith('.html')) docs['/docs/'+file]=(await readFile('public/docs/'+file)).toString('base64');
function installBundledDocs(bundledDocs, isDocument = false) {
  if (isDocument) {
    const back = document.querySelector('a.back[href="/"]');
    if (back) back.textContent = '← Close document to return to BizBazooka';
  }
  document.addEventListener('click', function (e) {
    const a = e.target.closest('a[href]');
    if (!a) return;
    const path = a.getAttribute('href');
    if (isDocument && path === '/') { e.preventDefault(); window.close(); return; }
    const encoded = bundledDocs[path];
    if (!encoded) return;
    e.preventDefault();
    let content = new TextDecoder().decode(Uint8Array.from(atob(encoded), c => c.charCodeAt(0)));
    const runtime = '<script>(' + installBundledDocs.toString() + ')(' + JSON.stringify(bundledDocs) + ',true);<' + '/script>';
    content = content.replace('</body>', runtime + '</body>');
    const url = URL.createObjectURL(new Blob([content], { type: 'text/html;charset=utf-8' }));
    window.open(url, '_blank', 'noopener');
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }, true);
}
const offlineDocs = `<script>(${installBundledDocs.toString()})(${JSON.stringify(docs)});</script>`;
html = html.replace('</body>', `${offlineDocs}</body>`);
await writeFile('BizBazooka-demo.html', html);
await writeFile('dist/BizBazooka-demo.html', html);
console.log(`Exported BizBazooka-demo.html (${Math.round(Buffer.byteLength(html) / 1024)} KB). Includes code, styles, portraits, fonts, PRD, research, and QA.`);
