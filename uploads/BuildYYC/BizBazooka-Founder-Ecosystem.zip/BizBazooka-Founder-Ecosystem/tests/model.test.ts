import test from 'node:test';
import assert from 'node:assert/strict';
import { seedStore, createNeed, evaluate, getMatches, availableHours, transitionRequest, validateNeed, addDays, today, type Collaboration } from '../src/model.ts';

test('default need produces three eligible builders and excludes unavailable profiles', () => {
  const store = seedStore(); const need = createNeed();
  const matches = getMatches(store.builders, need);
  assert.equal(matches.length, 3);
  assert.deepEqual(new Set(matches.map(m => m.builder.id)), new Set(['priya', 'daniel', 'olivia']));
  assert.ok(evaluate(store.builders.find(b => b.id === 'marcus')!, need).blockers.includes('No available hours'));
  assert.ok(evaluate(store.builders.find(b => b.id === 'amara')!, need).blockers.some(x => x.includes('Only 6')));
});
test('eligibility requires every skill, with case-insensitive comparison', () => {
  const b = seedStore().builders[0]; const need = createNeed();
  assert.equal(evaluate(b, { ...need, skills: ['react native', 'STRIPE'] }).eligible, true);
  assert.equal(evaluate(b, { ...need, skills: ['React Native', 'Kotlin'] }).eligible, false);
});
test('matching requires role, consent, compatible terms and fresh availability', () => {
  const b = seedStore().builders[0]; const need = createNeed();
  for (const changed of [{ ...b, consent: false }, { ...b, discipline: 'Designer' }, { ...b, terms: [] }, { ...b, updated: addDays(today(), -15) }]) assert.equal(evaluate(changed, need).eligible, false);
});
test('availability must cover the entire requested duration', () => {
  const b = seedStore().builders[0]; const need = createNeed();
  assert.equal(evaluate({ ...b, availableUntil: addDays(need.start, 28) }, need).eligible, false);
  assert.equal(evaluate({ ...b, availableUntil: addDays(need.start, 42) }, need).eligible, true);
});
test('no candidates means no invented matches; fewer candidates stay fewer', () => {
  const s = seedStore(); const n = createNeed();
  assert.equal(getMatches(s.builders, { ...n, hours: 40 }).length, 0);
  assert.equal(getMatches(s.builders.slice(0, 1), n).length, 1);
});
function request(status: Collaboration['status'] = 'sent'): Collaboration {
  return { id: 'request-1', builderId: 'priya', need: createNeed(), note: 'Hello', status, created: new Date().toISOString() };
}
test('accepted commitments consume capacity only when dates overlap', () => {
  const b = seedStore().builders[0]; const r = request('accepted');
  assert.equal(availableHours(b, r.need, [r]), 0);
  assert.equal(availableHours(b, { ...r.need, start: addDays(r.need.start, 42) }, [r]), 8);
  assert.equal(availableHours(b, r.need, [{ ...r, status: 'sent' }]), 8);
});
test('only the assigned builder can accept; founder can withdraw', () => {
  const s = seedStore(); s.requests = [request()];
  assert.throws(() => transitionRequest(s, 'request-1', 'accepted', 'daniel'));
  assert.throws(() => transitionRequest(s, 'request-1', 'accepted', 'founder'));
  assert.equal(transitionRequest(s, 'request-1', 'accepted', 'priya').requests[0].status, 'accepted');
  assert.equal(transitionRequest(s, 'request-1', 'withdrawn', 'founder').requests[0].status, 'withdrawn');
  assert.throws(() => transitionRequest(s, 'request-1', 'withdrawn', 'priya'));
});
test('terminal responses cannot be repeated or rewritten', () => {
  const s = seedStore(); s.requests = [request('accepted')];
  assert.throws(() => transitionRequest(s, 'request-1', 'declined', 'priya'));
  assert.throws(() => transitionRequest(s, 'request-1', 'accepted', 'priya'));
});
test('acceptance revalidates capacity against another accepted commitment', () => {
  const s = seedStore(); const r = request();
  s.requests = [r, { ...r, id: 'other', status: 'accepted', need: { ...r.need, id: 'other-project' } }];
  assert.throws(() => transitionRequest(s, r.id, 'accepted', 'priya'), /Capacity/);
});
test('invalid hours, duration, skills, preferences and start date are rejected', () => {
  const n = createNeed(); assert.equal(validateNeed(n), undefined);
  for (const invalid of [{ ...n, hours: 0 }, { ...n, hours: 41 }, { ...n, weeks: 0 }, { ...n, skills: [] }, { ...n, terms: [] }, { ...n, project: ' ' }, { ...n, start: addDays(today(), -1) }]) assert.ok(validateNeed(invalid));
});
